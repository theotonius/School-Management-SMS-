<style>
  .exam_chart {
    width       : 100%;
    height      : 265px;
    font-size   : 11px;
  }
</style>

<?php
  $staff_info = $this->db->get_where('staff', array('staff_id' => $staff_id))->result_array();
  foreach ($staff_info as $row):

?>
<div class="profile-env" id="profile">
  <header class="row">
    <div class="col-md-3">
      <center>
        <a href="#">
          <img src="<?php echo $this->crud_model->get_image_url('staff', $staff_id) ;?>" class="img-circle"
          style="width: 60%;" />
        </a>
        <br>
        <h3>
          <?php echo $row['name']; ?>
        </h3>
        <br>
        <span>
         
        
        </span>
      </center>
    </div>
    <div class="col-md-9">

    <ul class="nav nav-tabs">
      <li class="active"><a href="#tab1" data-toggle="tab" class="btn btn-default">
          <span class="visible-xs"><i class="entypo-home"></i></span>
          <span class="hidden-xs"><?php echo get_phrase('basic_info'); ?></span>
        </a>
      </li>
      <li class="active pull-right"><a href=""  onClick="window.print(); return false" class="btn btn-default">
          <span class="visible-xs"><i class="entypo-home"></i></span>
          <span class="hidden-xs"><?php echo get_phrase('print'); ?></span>
        </a>
      </li>
   
    </ul>

    <div class="tab-content">
      <div class="tab-pane active" id="tab1">
        <?php
          $basic_info_titles = ['name','bnname','designation','blood_group','religion', 'email', 'phone','voter_id', 'birthday', 'gender','address' ];
          $basic_info_values = [$row['name'], $row['bnname'],$row['designation'],$row['blood_group'], $row['religion'], $row['email'], $row['phone'] == NULL ? '' : $row['phone'], $row['voter_id'] == NULL ? '' : $row['voter_id'], $row['birthday'], $row['sex'] == NULL ? '' : $row['sex'], $row['address'] == NULL ? '' : $row['address'], 
          $row['dormitory_id'] == NULL ? '' : $this->db->get_where('dormitory', array('dormitory_id' => $row['dormitory_id']))->row()->name];
        ?>
        <table class="table table-bordered" style="margin-top: 20px;">
          <tbody>
          <?php for ($i=0; $i < count($basic_info_titles) ; $i++) { ?>
            <tr>
              <td width="30%">
                <strong><?php echo get_phrase($basic_info_titles[$i]); ?></strong>
              </td>
              <td><?php echo $basic_info_values[$i]; ?></td>
            </tr>
          <?php } ?>
          </tbody>
        </table>
      </div>
      
      
      
    </div>

    <br>

  </div>
  </header>
</div>
<?php endforeach; ?>
<script>
    profile.render();
    document.getElementById("profile-env").addEventListener("click",function(){
        window.print();
    });     
</script>