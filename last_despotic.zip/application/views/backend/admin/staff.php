
            <a href="javascript:;" onclick="showAjaxModal('<?php echo site_url('modal/popup/modal_staff_add/');?>');"
            	class="btn btn-primary pull-right">
                <i class="entypo-plus-circled"></i>
            	<?php echo get_phrase('add_new_staff');?>
                </a>
                <br><br>
               <table class="table table-bordered datatable" id="staffs">
                    <thead>
                        <tr>
                            <th width="60"><div><?php echo get_phrase('id');?></div></th>
                            <th width="80"><div><?php echo get_phrase('photo');?></div></th>
                            <th><div><?php echo get_phrase('name');?></div></th>
                            <th><div><?php echo get_phrase('bnname');?></div></th>
                            <th><div><?php echo get_phrase('designation');?></div></th>
                            <th><div><?php echo get_phrase('email').'/'.get_phrase('username');?></div></th>
                            <th><div><?php echo get_phrase('phone');?></div></th>
                            <th><div><?php echo get_phrase('options');?></div></th>
                        </tr>
                    </thead>
                </table>



<!-----  DATA TABLE EXPORT CONFIGURATIONS ---->
<script type="text/javascript">

	jQuery(document).ready(function($) {
        $.fn.dataTable.ext.errMode = 'throw';
        $('#staffs').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax":{
                "url": "<?php echo site_url('admin/get_staffs') ?>",
                "dataType": "json",
                "type": "POST",
            },
            "columns": [
                { "data": "staff_id" },
                { "data": "photo" },
                { "data": "name" },
                { "data": "bnname" },
                { "data": "designation" },
                { "data": "email" },
                { "data": "phone" },
                { "data": "options" },
            ],
            "columnDefs": [
                {
                    "targets": [1,5],
                    "orderable": false
                },
            ]
        });
	});

   
    function staff_edit_modal(staff_id) {
        showAjaxModal('<?php echo site_url('modal/popup/modal_staff_edit/');?>' + staff_id);
    }

    function staff_delete_confirm(staff_id) {
        confirm_modal('<?php echo site_url('admin/staff/delete/');?>' + staff_id);
    }

</script>
